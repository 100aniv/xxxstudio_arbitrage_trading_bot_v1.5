# gui.py (업데이트 완료)
from PyQt6.QtWidgets import QMainWindow, QVBoxLayout, QPushButton, QLabel, QWidget, QLineEdit, QCheckBox
from PyQt6.QtCore import Qt


class TradingBotGUI(QMainWindow):
    def __init__(self, strategy_manager, data_collector):
        super().__init__()
        self.strategy_manager = strategy_manager
        self.data_collector = data_collector

        self.setWindowTitle("Trading Bot - Login")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        # 이메일
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("이메일 입력")
        layout.addWidget(self.email_input)

        # 업비트 API Key
        self.upbit_key_input = QLineEdit()
        self.upbit_key_input.setPlaceholderText("업비트 API Key")
        layout.addWidget(self.upbit_key_input)

        # 바이낸스 API Key
        self.binance_key_input = QLineEdit()
        self.binance_key_input.setPlaceholderText("바이낸스 API Key")
        layout.addWidget(self.binance_key_input)

        # 텔레그램 Bot Token
        self.telegram_token_input = QLineEdit()
        self.telegram_token_input.setPlaceholderText("텔레그램 Bot Token")
        layout.addWidget(self.telegram_token_input)

        # 로그인 유지 체크박스
        self.remember_me_checkbox = QCheckBox("로그인 유지")
        layout.addWidget(self.remember_me_checkbox)

        # 로그인 버튼
        self.login_button = QPushButton("저장 및 로그인")
        self.login_button.clicked.connect(self.handle_login)
        layout.addWidget(self.login_button)

        # 메인 위젯
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def handle_login(self):
        # 간단한 예제: 입력된 정보 확인
        email = self.email_input.text()
        upbit_key = self.upbit_key_input.text()
        binance_key = self.binance_key_input.text()
        print(f"이메일: {email}, 업비트 Key: {upbit_key}, 바이낸스 Key: {binance_key}")
