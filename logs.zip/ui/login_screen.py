
# login_screen.py
# 자동 로그인 기능이 포함된 로그인 화면입니다.

from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel, QLineEdit, QCheckBox
import sys
from config.config_handler import ConfigHandler
from ui.gui import TradingBotGUI
import os

class LoginScreen(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Trading Bot Login')
        self.setGeometry(100, 100, 400, 300)
        self.config = ConfigHandler()
        self.initUI()

        # 자동 로그인 확인
        self.check_auto_login()

    def initUI(self):
        """
        로그인 화면 레이아웃 구성 및 자동 로그인 설정
        """
        layout = QVBoxLayout()
        self.email_input = QLineEdit()
        self.email_input.setPlaceholderText("이메일 입력")

        self.upbit_api_input = QLineEdit()
        self.upbit_api_input.setPlaceholderText("업비트 API Key")
        self.upbit_secret_input = QLineEdit()
        self.upbit_secret_input.setPlaceholderText("업비트 Secret Key")

        self.binance_api_input = QLineEdit()
        self.binance_api_input.setPlaceholderText("바이낸스 API Key")
        self.binance_secret_input = QLineEdit()
        self.binance_secret_input.setPlaceholderText("바이낸스 Secret Key")

        self.telegram_token_input = QLineEdit()
        self.telegram_token_input.setPlaceholderText("텔레그램 Token")

        self.remember_me_checkbox = QCheckBox("로그인 유지 (자동 로그인)")
        self.login_button = QPushButton("저장 및 로그인")
        self.login_button.clicked.connect(self.save_and_login)

        # 레이아웃 추가
        layout.addWidget(QLabel("📧 이메일:"))
        layout.addWidget(self.email_input)
        layout.addWidget(QLabel("🔑 업비트 API Key:"))
        layout.addWidget(self.upbit_api_input)
        layout.addWidget(QLabel("🔑 업비트 Secret Key:"))
        layout.addWidget(self.upbit_secret_input)
        layout.addWidget(QLabel("🔑 바이낸스 API Key:"))
        layout.addWidget(self.binance_api_input)
        layout.addWidget(QLabel("🔑 바이낸스 Secret Key:"))
        layout.addWidget(self.binance_secret_input)
        layout.addWidget(QLabel("📡 텔레그램 Token:"))
        layout.addWidget(self.telegram_token_input)
        layout.addWidget(self.remember_me_checkbox)
        layout.addWidget(self.login_button)

        # 메인 레이아웃 적용
        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def save_and_login(self):
        """
        사용자가 로그인 정보를 입력하고, 자동 로그인 여부를 저장
        """
        self.config.encrypt(self.upbit_api_input.text())
        self.config.encrypt(self.binance_api_input.text())
        
        # 자동 로그인 설정 확인
        if self.remember_me_checkbox.isChecked():
            with open(".env", "a") as env_file:
                env_file.write("\nAUTO_LOGIN=True")

        # 메인 대시보드로 전환
        self.close()
        self.dashboard = TradingBotGUI()
        self.dashboard.show()

    def check_auto_login(self):
        """
        .env 파일에서 자동 로그인 여부를 확인하고, 조건에 맞으면 자동 로그인 실행
        """
        auto_login = os.getenv("AUTO_LOGIN")
        if auto_login == "True":
            self.dashboard = TradingBotGUI()
            self.dashboard.show()
            self.close()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    login_screen = LoginScreen()
    login_screen.show()
    sys.exit(app.exec())
