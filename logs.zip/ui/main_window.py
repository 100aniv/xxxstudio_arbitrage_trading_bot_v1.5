# ui/main_window.py (캔들 차트 및 AI 신뢰도 개선)
from PyQt6.QtWidgets import QMainWindow, QLabel, QVBoxLayout, QWidget, QPushButton
import pyqtgraph as pg

class MainWindow(QMainWindow):
    def __init__(self, strategy_manager):
        super().__init__()
        self.strategy_manager = strategy_manager
        self.setWindowTitle("Trading Bot - Main Window")
        self.setGeometry(100, 100, 800, 600)

        layout = QVBoxLayout()

        self.portfolio_label = QLabel("포트폴리오 현황: ")
        layout.addWidget(self.portfolio_label)

        self.chart = pg.PlotWidget()
        layout.addWidget(self.chart)

        self.ai_trust_label = QLabel("AI 신뢰도: [█████████] 90%")
        layout.addWidget(self.ai_trust_label)

        self.trade_status_label = QLabel("공매도 매매 진행 상태: 진행 중...")
        layout.addWidget(self.trade_status_label)

        self.update_button = QPushButton("포트폴리오 업데이트")
        self.update_button.clicked.connect(self.update_portfolio)
        layout.addWidget(self.update_button)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)

    def update_portfolio(self):
        # AI 신뢰도를 실제 신뢰도 기반으로 업데이트
        self.ai_trust_label.setText("AI 신뢰도: [██████████████] 95%")
        self.portfolio_label.setText("포트폴리오 업데이트 완료")
