# strategy_manager.py (업데이트 완료)
from strategies.rsi_strategy import RSIStrategy
from strategies.macd_strategy import MACDStrategy
from strategies.ema_strategy import EMAStrategy

class StrategyManager:
    def __init__(self):
        self.strategies = {
            "RSI": RSIStrategy(),
            "MACD": MACDStrategy(),
            "EMA": EMAStrategy()
        }
        self.results = {}

    def apply_strategies(self, data):
        if data is None:
            print("데이터가 비어있어 전략을 적용할 수 없습니다.")
            return
        for name, strategy in self.strategies.items():
            try:
                self.results[name] = strategy.generate_signal(data.copy())
            except KeyError as e:
                print(f"{name} 전략에서 KeyError 발생: {e}")

    def compare_performance(self):
        performance = {}
        for name, result in self.results.items():
            profit = (result['signal'] * result['close']).sum()
            performance[name] = profit
        return performance
