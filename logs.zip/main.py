# main.py (업데이트 완료)
from ui.gui import TradingBotGUI
from data.data_collector import DataCollector
from strategies.strategy_manager import StrategyManager
from PyQt6.QtWidgets import QApplication
import sys

def main():
    app = QApplication(sys.argv)

    # 데이터 수집기 & 전략 관리자 초기화
    data_collector = DataCollector()
    data_collector.start_streaming()

    strategy_manager = StrategyManager()

    # GUI 초기화
    gui = TradingBotGUI(strategy_manager, data_collector)
    gui.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
