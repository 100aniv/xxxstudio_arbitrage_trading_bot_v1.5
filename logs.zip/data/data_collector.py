# data_collector.py (업데이트 완료: 업비트와 바이낸스 WebSocket 멀티스레딩)
import websocket
import json
import threading

class DataCollector:
    def __init__(self):
        self.upbit_data = None
        self.binance_data = None
        self.received_data = False

    def start_streaming(self):
        # 멀티스레딩으로 업비트와 바이낸스 동시 데이터 수집 시작
        upbit_thread = threading.Thread(target=self.collect_upbit_data)
        binance_thread = threading.Thread(target=self.collect_binance_data)
        upbit_thread.start()
        binance_thread.start()

    def collect_upbit_data(self):
        """업비트 KRW-BTC WebSocket 연결 및 ticker 메시지 수집"""
        def on_message(ws, message):
            try:
                self.upbit_data = json.loads(message)
                self.received_data = True
                print("업비트 데이터 수집 성공:", self.upbit_data)
            except Exception as e:
                print(f"업비트 데이터 수집 오류: {e}")

        def on_open(ws):
            # KRW-BTC ticker 메시지 구독 (업비트)
            subscribe_msg = json.dumps([
                {"ticket": "test"},
                {"type": "ticker", "codes": ["KRW-BTC"]}
            ])
            ws.send(subscribe_msg)
            print("업비트 WebSocket 구독 시작")

        ws = websocket.WebSocketApp(
            "wss://api.upbit.com/websocket/v1",
            on_message=on_message,
            on_open=on_open
        )
        ws.run_forever()

    def collect_binance_data(self):
        """바이낸스 BTCUSDT WebSocket 연결"""
        def on_message(ws, message):
            try:
                self.binance_data = json.loads(message)
                self.received_data = True
                print("바이낸스 데이터 수집 성공:", self.binance_data)
            except Exception as e:
                print(f"바이낸스 데이터 수집 오류: {e}")

        ws = websocket.WebSocketApp(
            "wss://stream.binance.com:9443/ws/btcusdt@trade",
            on_message=on_message
        )
        ws.run_forever()

    def get_latest_data(self):
        """최신 데이터를 반환"""
        return {
            "upbit": self.upbit_data,
            "binance": self.binance_data
        }

