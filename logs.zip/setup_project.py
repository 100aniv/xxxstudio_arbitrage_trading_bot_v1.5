
# setup_project.py
# 프로젝트 초기 설정 파일
import os

def setup_environment():
    os.system("pip install -r requirements.txt")

if __name__ == "__main__":
    setup_environment()
